package com.example.linxsystem.products;


import android.app.AlertDialog;
import android.content.Context;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;


import java.util.Collections;
import java.util.List;



import com.example.linxsystem.R;



public class Adapter_products extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Context context;
    private LayoutInflater inflater;
    List<Data_products> data = Collections.emptyList();
    Data_products current;
    int currentPos = 0;

    // create constructor to innitilize context and data sent from MainActivity
    public Adapter_products(Context context, List<Data_products> data) {
        this.context = context;
        inflater = LayoutInflater.from(context);
        this.data = data;
    }

    // Inflate the layout when viewholder created
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.container_products, parent, false);
        com.example.linxsystem.products.Adapter_products.MyHolder holder = new com.example.linxsystem.products.Adapter_products.MyHolder(view);
        return holder;
    }

    // Bind data
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {

        // Get current position of item in recyclerview to bind data and assign values from list
        final MyHolder myHolder = (MyHolder) holder;
        final Data_products current = data.get(position);
         myHolder.textView_pname.setText(current.product_name);
        // myHolder.textFishName.setTextColor(ContextCompat.getColor(context, R.color.colorPrimary));
        // myHolder.textView_Descr.setText(current.policy_description);
        // myHolder.textType.setText(current.policy_amount);
        // myHolder.textPrice.setText(current.nationalId );
        // myHolder.textDate.setText(current.status);
        // myHolder.textPrice.setTextColor(ContextCompat.getColor(context, R.color.colorAccent));

        // load image into imageview using glide
        Glide.with(context).load("http://www.fusiondc.co.zw/linxsystem/storage/cover_images/" + current.cover_image)
                //  .placeholder(R.drawable.ic_menu_camera)
                // .error(R.drawable.ic_menu_camera)
                .into(myHolder.ivFish);


        myHolder.constraintLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context,"you clicked ",Toast.LENGTH_LONG).show();

                //setting a dialog
                LayoutInflater li = LayoutInflater.from(context);
                View dialogView = li.inflate(R.layout.product_dialog, null);
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);

                //setting dialog title

                alertDialogBuilder.setTitle("Product Details");
                alertDialogBuilder.setIcon(R.drawable.linx);
                alertDialogBuilder.setView(dialogView);

                ImageView image = dialogView.findViewById(R.id.image1);
                TextView title = dialogView.findViewById(R.id.textViewTitle);
                TextView shortdesc = dialogView.findViewById(R.id.textViewShortDesc);
                TextView rating1 = dialogView.findViewById(R.id.textViewRating);

                // load image into imageview using glide

                Glide.with(context).load("http://www.fusiondc.co.zw/linxsystem/storage/cover_images/" + current.getCover_image()).into(image);

                title.setText( "  Product Name : " + current.getProduct_name());
                shortdesc.setText("Product Description : " + current.getProduct_description());
                rating1.setText(" Product Price : " + current.getProduct_price());


                alertDialogBuilder

                        .setPositiveButton("Visit Site",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialogBox, int id) {
                                       /* Intent intent = new Intent(Intent.ACTION_DIAL);
                                        String temp = "tel:" + current.getPhone();
                                        intent.setData(Uri.parse(temp));
                                        context.startActivity(intent);*/
                                        String url = "http://fusiondc.co.zw/linxsystem/";
                                        Intent i = new Intent(Intent.ACTION_VIEW);
                                        i.setData(Uri.parse(url));
                                        context.startActivity(i);
                                    }
                                });

              /*  String url = "http://www.example.com";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);*/

                alertDialogBuilder.setCancelable(false).setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogBox, int id) {
                                dialogBox.cancel();
                            }
                        });

                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();

            }


        });


    }

    // return total item from List
    @Override
    public int getItemCount() {
        return data.size();
    }


    class MyHolder extends RecyclerView.ViewHolder{

         TextView textView_pname;
        ImageView ivFish;
        TextView textView_Descr;
        ConstraintLayout constraintLayout;

        // create constructor to get widget reference
        public MyHolder(View itemView) {
            super(itemView);
            textView_pname= (TextView) itemView.findViewById(R.id.textView);
            ivFish= itemView.findViewById(R.id.ivFish);
            //textView_Descr = (TextView) itemView.findViewById(R.id.textView_Description);
            constraintLayout= itemView.findViewById(R.id.relative);
        }

    }

}
