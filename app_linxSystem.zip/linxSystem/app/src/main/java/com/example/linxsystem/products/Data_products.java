package com.example.linxsystem.products;

public class Data_products {


    // public int Id;
    public String cover_image;
    public String product_name;
    public String product_description;
    public String product_price;
    // public String status;





    public Data_products(String product_name,String cover_image,String product_description,String product_price) {
        //this.Id=Id;
        this.product_name = product_name;
        this.product_description = product_description;
        this.product_price = product_price;
        //this.status = status;

        this.cover_image = cover_image;
    }

    public Data_products() {

    }
    public String getProduct_name() {
        return product_name;
    }

    public String getProduct_description() {
        return product_description;
    }

    public String getProduct_price() {
        return product_price;
    }




    public  String getCover_image() {
        return cover_image;
    }}







