package com.example.linxsystem.users;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.linxsystem.R;
import com.example.linxsystem.products.Products;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;



public class SignIn extends Activity {
    EditText etEmail, etPassword;
    Button btnLogin;
    TextView txtGotoSignup;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        etPassword = findViewById(R.id.editText14);
        etEmail = findViewById(R.id.editText13);
        btnLogin = findViewById(R.id.button6);
        txtGotoSignup = findViewById(R.id.textView18);


        txtGotoSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SignIn.this, SignUp.class);
                startActivity(intent);
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });
    }

    private void login(){
        final ProgressDialog progressDialog = ProgressDialog.show(SignIn.this, "Logging in", "Please wait", false, false);
        final String email = etEmail.getText().toString().trim();
        final String password = etPassword.getText().toString().trim();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://www.fusiondc.co.zw/linxsystem/app_files/prosper/login.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.i("response",response);
                progressDialog.dismiss();
                try{
                    JSONObject object = new JSONObject(response);
                    Boolean error = Boolean.parseBoolean(object.optString("error"));
                    String email = object.optString("email");
                    String name = object.optString("name");
                   // String policy_status = object.optString("policy_status");
                    if ( !error) {
                        SharedPreferences sharedPreferences = SignIn.this.getSharedPreferences(Config.SHARED_PREF_NAME, Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putBoolean(Config.LOGGEDIN_SHARED_PREF, true);
                        editor.putString(Config.EMAIL, email);
                        editor.putString(Config.NAME, name);
                       // editor.putString(Config.POLICY_STATUS, policy_status);
                        editor.apply();
                        Intent intent = new Intent(SignIn.this, Products.class);
                        startActivity(intent);
                    } else {
                        progressDialog.dismiss();
                        //Toast.makeText(LoginActivity.this, response + "SOmethingg went wrong", Toast.LENGTH_LONG).show();
                    }
                }catch (JSONException e){

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(SignIn.this, error.toString(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("email", email);
                params.put("password", password);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(20 * 1000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(stringRequest);
    }
}
