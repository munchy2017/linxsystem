package com.example.linxsystem.users;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.example.linxsystem.R;




import static com.example.linxsystem.users.Config.SHARED_PREF_NAME;


public class Profile extends AppCompatActivity {
    TextView policynumber, policyStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        policynumber = findViewById(R.id.txtPolicyNumber);
        policyStatus = findViewById(R.id.txtPolicyStatus);

        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        String stremail = sharedPreferences.getString(Config.EMAIL,"Not found");
       // String strpolicy_status = sharedPreferences.getString(Config.POLICY_STATUS, "Not found");
        String strname = sharedPreferences.getString(Config.NAME, "Not found");
        //Toast.makeText(this, strpolicy_number+strpolicy_status, Toast.LENGTH_SHORT).show();

        policyStatus.setText("Name is: "+ strname);
        policynumber.setText("Email is: " +stremail);

    }
}
