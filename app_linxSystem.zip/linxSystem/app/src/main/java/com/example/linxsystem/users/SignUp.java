package com.example.linxsystem.users;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.linxsystem.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;



public class SignUp extends Activity {
    TextView login;
    EditText etEmail, etName, etPassword;
    Button btnSignup;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        etName = findViewById(R.id.editText17);
        etEmail = findViewById(R.id.editText15);
        etPassword = findViewById(R.id.editText16);
        btnSignup = findViewById(R.id.button7);
        login= findViewById(R.id.textView19);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent login= new Intent(SignUp.this,SignIn.class);
                startActivity(login);
            }
        });

        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });

    }

    private void registerUser(){
        final ProgressDialog progressDialog = ProgressDialog.show(SignUp.this, "Signing you in", "Please wait", false, false);
        final String name = etName.getText().toString().trim();
        final String password = etPassword.getText().toString().trim();
        final String email = etEmail.getText().toString().trim();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://www.fusiondc.co.zw/linxsystem/app_files/prosper/register.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.i("response",response);
                progressDialog.dismiss();
                try {
                    JSONObject object = new JSONObject(response);
                    Boolean error = Boolean.parseBoolean(object.optString("error"));
                    String email = object.optString("email");
                    String name = object.optString("name");
                    //String policy_status = object.optString("policy_status");
                    String message = object.optString("message");

                    if (!error) {
                        //Creating a shared preference
                        SharedPreferences sharedPreferences = SignUp.this.getSharedPreferences(Config.SHARED_PREF_NAME, Context.MODE_PRIVATE);

                        //Creating editor to store values to shared preferences
                        SharedPreferences.Editor editor = sharedPreferences.edit();

                        //Adding values to editor
                        editor.putBoolean(Config.LOGGEDIN_SHARED_PREF, true);
                        editor.putString(Config.EMAIL, email);
                        editor.putString(Config.NAME, name);
                        //editor.putString(Config.POLICY_STATUS, policy_status);
                        editor.apply();

                        //Saving values to editor
                        editor.apply();
                        Intent intent = new Intent(SignUp.this, SignIn.class);
                        startActivity(intent);
                    } else {
                        progressDialog.dismiss();
                        Toast.makeText(SignUp.this, message, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(SignUp.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(SignUp.this, error.toString(), Toast.LENGTH_SHORT).show();
                Log.d("An error occured", error.toString());
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("name", name);
                params.put("password", password);
                params.put("email", email);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(20 * 1000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(stringRequest);

    }
}
