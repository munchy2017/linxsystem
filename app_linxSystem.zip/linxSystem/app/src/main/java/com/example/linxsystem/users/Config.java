package com.example.linxsystem.users;

public class Config {

    public static final String SHARED_PREF_NAME = "prefs";

    //This would be used to store the details of current logged in user
   // public static final String POLICY_STATUS = "policy_status";
    public static final String LOGGEDIN_SHARED_PREF = "loggedin";
    public static final String EMAIL = "email";
    public static final String NAME = "fullname";
}


