<?php $__env->startSection('content'); ?>

      <h1> Welcome To LinxSystem</h1>
      <p>This is our demo system we are adding the link to our app soon</p>  
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>