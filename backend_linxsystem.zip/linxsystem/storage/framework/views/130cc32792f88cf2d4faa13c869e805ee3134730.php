<?php $__env->startSection('content'); ?>
<h1> Products</h1>
<?php if(count($products)>0): ?>
   <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <div class="well">
    <h3><a href="/products/<?php echo e($product->id); ?>"><?php echo e($product->product_name); ?></a></h3>
    <small>Posted On: <?php echo e($product->created_at); ?></small>
       <!--<div class="row">
           <div class="col-md-4 col-sm-4">
           <img style="width:100%" src="/storage/cover_images/<?php echo e($product->cover_image); ?>">
           </div>
             <div class="col-md-4 col-sm-8">
            

                <h3><a href="/products/<?php echo e($product->id); ?>"><?php echo e($product->product_name); ?></a></h3>
                <small>Posted On: <?php echo e($product->created_at); ?></small>
              </div>
       </div>-->
   </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($products->links()); ?>

<?php else: ?>
  <p>No products found</p>
 <?php endif; ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>