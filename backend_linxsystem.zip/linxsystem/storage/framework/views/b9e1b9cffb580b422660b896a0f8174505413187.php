<?php $__env->startSection('content'); ?>
 
<h1> Create Products</h1>
<?php echo Form::open(['action' => 'ProductsController@store', 'method' => 'POST','enctype'=>'multipart/form-data']); ?>

<div class="form-group">
    <?php echo e(Form::label('product_name', 'Product Name')); ?>

    <?php echo e(Form::text('product_name','',['class'=> 'form-control','placeholder'=>'Product_name'])); ?>

</div> 

<div class="form-group">
    <?php echo e(Form::label('product_description', 'Product Description')); ?>

    <?php echo e(Form::text('product_description','',['class'=> 'form-control','placeholder'=>'Product_Description'])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::label('product_price', 'Product Price')); ?>

    <?php echo e(Form::text('product_price','',['class'=> 'form-control','placeholder'=>'Product_Price'])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::file('cover_image')); ?>

</div>

<?php echo e(Form::submit('Submit',['class'=>'btn btn-primary'])); ?>

<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>