@extends('layouts.app')

@section('content')

      <h1> Welcome To LinxSystem</h1>
      <p>This is our demo system we are adding the link to our app soon</p>  
 @endsection