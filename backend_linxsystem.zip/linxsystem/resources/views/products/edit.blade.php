@extends('layouts.app')
@section('content')
 
<h1> Edit Product</h1>
{!! Form::open(['action' => ['ProductsController@update', $product->id], 'method' => 'POST']) !!}
<div class="form-group">
    {{Form::label('product_price', 'Product_Price')}}
    {{Form::text('product_price',$product->product_price,['class'=> 'form-control','placeholder'=>'Product Price'])}}
</div>  


{{Form::hidden('_method','PUT')}}
{{Form::submit('Submit',['class'=>'btn btn-primary'])}}
{!! Form::close() !!}

@endsection