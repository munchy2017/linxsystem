@extends('layouts.app')
@section('content')
 
<h1> Create Products</h1>
{!! Form::open(['action' => 'ProductsController@store', 'method' => 'POST','enctype'=>'multipart/form-data']) !!}
<div class="form-group">
    {{Form::label('product_name', 'Product Name')}}
    {{Form::text('product_name','',['class'=> 'form-control','placeholder'=>'Product_name'])}}
</div> 

<div class="form-group">
    {{Form::label('product_description', 'Product Description')}}
    {{Form::text('product_description','',['class'=> 'form-control','placeholder'=>'Product_Description'])}}
</div>

<div class="form-group">
    {{Form::label('product_price', 'Product Price')}}
    {{Form::text('product_price','',['class'=> 'form-control','placeholder'=>'Product_Price'])}}
</div>

<div class="form-group">
    {{Form::file('cover_image')}}
</div>

{{Form::submit('Submit',['class'=>'btn btn-primary'])}}
{!! Form::close() !!}

@endsection